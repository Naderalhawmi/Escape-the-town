﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shotting : MonoBehaviour
{
    public Transform firepoint;
    public GameObject bulletprefab1;
    public GameObject bulletprefab2;


    int numEnemies = 300;

    public float bulletforce = 20f;

    private void Update()
    {
        if (Input.GetButtonUp("Fire1"))
        {
            shoot1();
        }
        if (Input.GetButtonUp("Fire2"))
        {
            shoot2();
        }
    }

    void shoot1()
    {
        GameObject bullet =  Instantiate(bulletprefab1, firepoint.position, firepoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firepoint.up * bulletforce, ForceMode2D.Impulse);
    }

    void shoot2()
    {
        GameObject bullet = Instantiate(bulletprefab2, firepoint.position, firepoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firepoint.up * bulletforce, ForceMode2D.Impulse);
    }

}
